package studentpackage13;

// Base class Student
public class Student {
    public String name;
    public int roll_no;

    // Method to get data for student
    public void get_data(String name, int roll_no) {
        this.name = name;
        this.roll_no = roll_no;
    }

    // Method to display student data
    public void put_data() {
        System.out.println("Name: " + name);
        System.out.println("Roll No: " + roll_no);
    }
}
