package mypackage14;

// This is a public class, accessible from outside the package.
public class PublicClass {
    public void displayMessage() {
        System.out.println("Hello from PublicClass in mypackage!");
    }
}
