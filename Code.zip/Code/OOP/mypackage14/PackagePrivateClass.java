package mypackage14;

// This is a package-private class, not accessible from outside the package.
class PackagePrivateClass {
    public void displayMessage() {
        System.out.println("Hello from PackagePrivateClass in mypackage!");
    }
}
