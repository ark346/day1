package ccpackage13;

// Interface for CCA Score
public interface CCA_Score {
    int cca_cred = 10; // CCA credit data member

    // Method to display CCA credit
    void show_cca_cred();
}
