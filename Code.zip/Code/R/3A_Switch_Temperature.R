# Define a function to convert temperature between different units
# The function convert_temperature takes three arguments: temp (the temperature to convert),
# from_unit (the unit of the input temperature), and to_unit (the desired output unit).
convert_temperature <- function(temp, from_unit, to_unit) {
  # Use switch() to determine the conversion based on the from_unit
  switch(from_unit,
         # If the from_unit is Celsius (C)
         "C" = {
           # Use another switch() to handle conversions to other units
           switch(to_unit,
                  "F" = temp * 9/5 + 32,    # Convert C to F
                  "K" = temp + 273.15,      # Convert C to K
                  temp)                     # If no conversion, return original temperature
         },
         # If the from_unit is Fahrenheit (F)
         "F" = {
           switch(to_unit,
                  "C" = (temp - 32) * 5/9,  # Convert F to C
                  "K" = (temp - 32) * 5/9 + 273.15,  # Convert F to K
                  temp)                     # If no conversion, return original temperature
         },
         # If the from_unit is Kelvin (K)
         "K" = {
           switch(to_unit,
                  "C" = temp - 273.15,      # Convert K to C
                  "F" = (temp - 273.15) * 9/5 + 32,  # Convert K to F
                  temp)                     # If no conversion, return original temperature
         },
         # If an invalid from_unit is provided, stop the execution with an error message
         stop("Invalid source unit")
  )
}

# Prompt the user to enter a temperature
temp <- as.numeric(readline(prompt = "Enter the temperature: "))
# Prompt the user to enter the source unit (C, F, K)
from_unit <- readline(prompt = "Enter the source unit (C, F, K): ")
# Prompt the user to enter the target unit (C, F, K)
to_unit <- readline(prompt = "Enter the target unit (C, F, K): ")

# Call the conversion function with the user inputs and store the result
converted_temp <- convert_temperature(temp, from_unit, to_unit)

# Print the converted temperature with the target unit
cat("The converted temperature is:", converted_temp, to_unit, "\n")
