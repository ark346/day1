heights <- c(160, 165, 170, 175, 180, 185, 190, 195, 200, 205)
weights <- c(50, 55, 60, 65, 70, 75, 80, 85, 90, 95)

correlation <- cor(heights, weights)

cat("Pearson correlation coefficient:", correlation, "\n")
