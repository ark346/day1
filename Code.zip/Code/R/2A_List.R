# Create a character vector a with names of students
# The c() function combines the strings "Ram", "Shyam", and "Ravan" into a vector.
a <- c("Ram", "Shyam", "Ravan")

# Create a numeric vector b with ages of the students
# The c() function combines the numbers 21, 22, and 23 into a vector.
b <- c(21, 22, 23)

# Create a numeric vector c with marks of the students
# The c() function combines the scores 74, 96, and 83 into a vector.
c <- c(74, 96, 83)

# Create a list L containing names, ages, and marks
# The list() function creates a list. Here, we name each element of the list 
# using the format "Name"=a, "Age"=b, and "Marks"=c.
L <- list("Name" = a, "Age" = b, "Marks" = c)

# Print the names of the students from the list L
# We access the "Name" element of the list L using the $ operator.
print(L$Name)

# Create another list M containing roll numbers
# The list() function creates a new list M with the roll numbers of the students.
M <- list("Roll" = c(1, 2, 3))

# Combine lists L and M into a single list LM
# The c() function is used to concatenate the two lists, resulting in a new list LM
# that contains all elements from both L and M.
LM <- c(L, M)

# Find the maximum score from the Marks in LM
# The max() function returns the maximum value from the specified vector, which is 
# the Marks from the list LM.
max <- max(LM$Marks)

# Get the names of the students who scored the highest mark
# We compare the max score with the Marks in LM. The expression `max == LM$Marks` 
# returns a logical vector indicating which marks are equal to the maximum score.
# We then use this logical vector to index the Names in LM to find the corresponding names.
max_score <- LM$Name[max == LM$Marks]

# Print the names of the students who scored the highest mark
# The cat() function prints the text without a newline, and then we print the 
# names stored in max_score.
cat("Name of the students who scored highest mark:")
print(max_score)
