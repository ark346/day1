# Create a numeric vector A with the values 1, 2, 3, 4, and 5 using seq()
# The seq() function generates a sequence of numbers. Here, it creates a vector 
# containing numbers from 1 to 5.
A <- seq(1, 5)

# Remove the 1st element from the vector
# The negative indexing (-1) is used to exclude the first element from the vector A.
# This operation effectively reduces the length of the vector by one.
A <- A[-1]

# Append the number 6 to the vector
# The c() function combines values into a vector. Here, we are adding the number 6 
# to the end of the existing vector A, effectively extending its length by one.
A <- c(A, 6)

# Add 1 as the 1st element of the vector
# Again, the c() function is used. This time, we are creating a new vector by combining 
# the value 1 at the front and the existing vector A, thus inserting 1 as the first element.
A <- c(1, A)

# Print the 3rd to 6th elements of the vector A
# We use indexing to extract a subset of the vector A. 
# A[3:6] selects the elements at positions 3, 4, 5, and 6 of vector A.
result <- A[3:6]
print(result)  # This line prints the selected elements to the console.

# Divide each element of the resultant vector by 2
# Here, we perform element-wise division on the vector result. Each element 
# in the result vector is divided by 2 to create a new vector called result_divided.
result_divided <- result / 2

# Print all the elements of the resultant vector that are greater than 1.5
# The condition result_divided > 1.5 creates a logical vector (TRUE/FALSE) 
# where each element is evaluated against the condition. 
# The filtered elements (where the condition is TRUE) are printed.
print(result_divided[result_divided > 1.5])
