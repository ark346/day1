# Load the Titanic dataset from the 'titanic' package. This command uses the data() function to load a built-in dataset.
data("titanic_train")

# Preview the first few rows of the titanic_train dataset to understand its structure and content.
head(titanic_train)

# Select only the relevant columns: "Survived", "Sex", and "Age". 
# The goal is to focus on these variables for our analysis and predictive modeling.
# Use na.omit() to remove rows that contain missing values (NAs) in these columns.
# This step ensures that the model doesn't encounter issues when there are missing data points.
titanic_clean <- na.omit(titanic_train[, c("Survived", "Sex", "Age")])

# Convert the "Sex" column from a character vector to a factor type.
# Factors are used for categorical data, and it's necessary to define them as factors for modeling.
titanic_clean$Sex <- as.factor(titanic_clean$Sex)

# Create a logistic regression model using the glm() function.
# The general format is: glm(response_variable ~ predictor_variables, data = dataset, family = distribution).
# Here:
# - 'Survived' is the response variable (1 = Survived, 0 = Did Not Survive)
# - 'Sex' and 'Age' are the predictor variables used to estimate survival.
# - 'data' is set to 'titanic_clean' (the cleaned dataset)
# - 'family = binomial' specifies that we are using a logistic regression model, which is suitable for binary outcomes.
model <- glm(Survived ~ Sex + Age, data = titanic_clean, family = binomial)

# Create a new data frame for a passenger with specific characteristics to make predictions.
# This new data frame has the same structure as the dataset used in the model.
# - 'Sex' is defined as 'male' and specified as a factor with the same levels as in the original dataset.
# - 'Age' is set to 35.
new_passenger <- data.frame(Sex = factor("male", levels = c("female", "male")), Age = 35)

# Use the predict() function to estimate the survival probability of the new passenger.
# - 'model' is the logistic regression model we created.
# - 'newdata' is set to 'new_passenger' to specify that we want predictions for this new data point.
# - 'type = "response"' ensures that the output is in probability form (rather than log-odds).
# The result is a single probability value indicating the likelihood of survival for a 35-year-old male.
predicted_survival_prob <- predict(model, newdata = new_passenger, type = "response")

# Print the predicted survival probability, rounded to four decimal places.
# The 'paste()' function is used to combine text and variables into a single string.
# 'round()' formats the probability to make it easier to interpret.
print(paste("The predicted survival probability for a 35-year-old male is:", round(predicted_survival_prob, 4)))
