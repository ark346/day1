# Define the mean and standard deviation
mean_acres <- 3500
sd_acres <- 800

# Calculate the probability for the given range using pnorm
probability <- pnorm(4200, mean = mean_acres, sd = sd_acres) - pnorm(2500, mean = mean_acres, sd = sd_acres)

# Print the result
print(paste("The probability that between 2,500 and 4,200 acres will be burned is:", round(probability, 4)))
