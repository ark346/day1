# Define a function to check the type of matrix (symmetric, skew-symmetric, or orthogonal).
check_matrix_type <- function(mat) {
  
  # Calculate the transpose of the given matrix
  mat_t <- t(mat)
  
  # Use the switch() function to evaluate different matrix properties.
  # The menu is used to provide a choice to the user for matrix evaluation.
  choice <- as.integer(readline(prompt = "Choose an option: \n1. Check for Symmetric Matrix \n2. Check for Skew-Symmetric Matrix \n3. Check for Orthogonal Matrix \n4. Check All \nEnter your choice: "))
  
  # Switch statement to evaluate based on user's choice
  switch(choice,
         
         # Case 1: Check if the matrix is symmetric.
         # A matrix is symmetric if it is equal to its transpose.
         {
           if (all(mat == mat_t)) {
             print("The matrix is Symmetric.")
           } else {
             print("The matrix is NOT Symmetric.")
           }
         },
         
         # Case 2: Check if the matrix is skew-symmetric.
         # A matrix is skew-symmetric if it is equal to the negative of its transpose.
         {
           if (all(mat == -mat_t)) {
             print("The matrix is Skew-Symmetric.")
           } else {
             print("The matrix is NOT Skew-Symmetric.")
           }
         },
         
         # Case 3: Check if the matrix is orthogonal.
         # A matrix is orthogonal if the product of the matrix and its transpose results in the identity matrix.
         {
           if (all(round(mat %*% mat_t, 10) == diag(nrow(mat)))) {
             print("The matrix is Orthogonal.")
           } else {
             print("The matrix is NOT Orthogonal.")
           }
         },
         
         # Case 4: Check all conditions.
         {
           # Check for symmetric matrix
           if (all(mat == mat_t)) {
             print("The matrix is Symmetric.")
           } else {
             print("The matrix is NOT Symmetric.")
           }
           
           # Check for skew-symmetric matrix
           if (all(mat == -mat_t)) {
             print("The matrix is Skew-Symmetric.")
           } else {
             print("The matrix is NOT Skew-Symmetric.")
           }
           
           # Check for orthogonal matrix
           if (all(round(mat %*% mat_t, 10) == diag(nrow(mat)))) {
             print("The matrix is Orthogonal.")
           } else {
             print("The matrix is NOT Orthogonal.")
           }
         }
  )
}

# Ask the user for the dimensions of the matrix (number of rows and columns)
n <- as.integer(readline(prompt = "Enter the number of rows and columns for the square matrix: "))

# Initialize an empty matrix of size n x n
user_matrix <- matrix(0, n, n)

# Use a nested loop to take input for each element of the matrix
for (i in 1:n) {
  for (j in 1:n) {
    user_matrix[i, j] <- as.numeric(readline(prompt = paste("Enter element [", i, ",", j, "] : ", sep = "")))
  }
}

# Display the user-entered matrix
print("The entered matrix is:")
print(user_matrix)

# Call the function to check matrix type using the input matrix
check_matrix_type(user_matrix)
