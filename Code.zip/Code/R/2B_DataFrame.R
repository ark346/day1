# Read student data from a CSV file
# The read.csv() function reads a comma-separated values (CSV) file into a data frame. 
# The specified path points to the location of the CSV file containing student marks.
student_data <- read.csv("C:/Users/Rakib Khan/Desktop/Code/R/student_marks.csv")

# Extract the first boy from the student data
# We use logical indexing to filter the data frame for rows where the Gender is "M". 
# The first boy is selected by indexing the first row with [1, ].
first_boy <- student_data[student_data$Gender == "M", ][1, ]

# Print the name of the first boy in the class
# The cat() function prints a message to the console, and print() displays the 
# details of the first boy extracted from the student data.
cat("The first boy of the class is:")
print(first_boy)

# Extract data for students who scored more than 60 in Math
# Again, we use logical indexing to filter the data frame for rows where the Math 
# scores are greater than 60. The result is stored in the math_above_60 variable.
math_above_60 <- student_data[student_data$Math > 60, ]

# Write the filtered data to a new CSV file
# The write.csv() function writes a data frame to a CSV file. The file path 
# specifies where to save the new CSV file, and row.names = FALSE excludes row names 
# from being written to the file.
write.csv(math_above_60, "C:/Users/Rakib Khan/Desktop/Code/R/math.csv", row.names = FALSE)

# Print a message indicating the data has been saved
# The cat() function again prints a message to the console, confirming that the 
# data of students who scored more than 60 has been written to the specified file.
cat("Data of the students who scored more than 60 is written in math.csv file")
