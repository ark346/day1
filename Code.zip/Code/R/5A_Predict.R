

# Manually create the dataset as a dataframe
house_data <- data.frame(
  SquareFeet = c(2100, 1600, 2400, 1416, 3000, 1985, 1534, 1427, 1380, 1494),
  Bedrooms   = c(3, 2, 4, 2, 4, 3, 3, 3, 3, 3),
  Age        = c(20, 15, 25, 18, 30, 20, 15, 24, 10, 5),
  Price      = c(400, 330, 450, 232, 540, 350, 270, 250, 290, 230)
)

# Print the dataset to verify its structure
print(house_data)

# Build a linear regression model to predict Price based on SquareFeet, Bedrooms, and Age
model <- lm(Price ~ SquareFeet + Bedrooms + Age, data = house_data)

# Display the summary of the model to understand coefficients
summary(model)

# Predict the price of a house with 2000 square feet, 3 bedrooms, and 20 years old
new_house <- data.frame(SquareFeet = 2000, Bedrooms = 3, Age = 20)
predicted_price <- predict(model, new_house)

# Print the predicted price
print(paste("The predicted price for the house is:", predicted_price))
