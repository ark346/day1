

# Read the Excel file into a dataframe
employees_data <- read_excel("C:/Users/Rakib Khan/Desktop/Code/R/Employees.xlsx")

# Filter the female employees in department 4
female_employees_dept4 <- employees_data[employees_data$Gender == "Female" & employees_data$Department == 4, ]

# Create full names by concatenating FirstName and LastName
full_names <- paste(female_employees_dept4$`First name`, female_employees_dept4$`Last Name`, sep = " ")

# Print the full names
print(full_names)
