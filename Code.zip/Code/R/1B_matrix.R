# Create matrix A with values 1 to 6
# The matrix() function creates a matrix. The first argument c(1:6) generates 
# a vector with values from 1 to 6. The nrow=3 argument specifies that 
# the matrix should have 3 rows, and byrow=TRUE fills the matrix by rows.
A <- matrix(c(1:6), nrow=3, byrow=TRUE)

# Create matrix B with values 7 to 12
# Similarly, we create another matrix B with values from 7 to 12, 
# also with 3 rows, filling by rows.
B <- matrix(c(7:12), nrow=3, byrow=TRUE)

# Combine matrices A and B column-wise
# The cbind() function combines matrices or vectors by columns. 
# Here, it combines matrix A and matrix B to create a new matrix m.
m <- cbind(A, B)

# Print the combined matrix m
# This line outputs the contents of matrix m to the console.
print(m)

# Remove the 3rd column from the matrix m
# The indexing m[,-3] is used to exclude the 3rd column of the matrix m. 
# The negative sign indicates that we want to drop that column.
m <- m[,-3]

# Calculate and print the sum of each row
# The rowSums() function computes the sum of the elements in each row 
# of the matrix m. The resulting vector containing row sums is then printed.
print(rowSums(m))
