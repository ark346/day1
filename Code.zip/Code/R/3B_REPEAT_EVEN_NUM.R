# Initialize an empty vector v to store user input values
v <- c()
# Initialize an empty vector new to store even values
new <- c()

# Print a message to indicate how to end the input process
print("Type exit to end the input process.")

# Start a repeat loop to continuously take input from the user
repeat {
  # Prompt the user to enter a value
  input <- readline("Enter a value: ")
  
  # Check if the input is "exit"; if so, break the loop
  if (input == "exit") {
    break
  }
  
  # Convert the input to an integer and append it to vector v
  v <- c(v, as.integer(input))
}

# Print the input vector v
cat("The input vector is:", v)

# Iterate over each value in the input vector v
for (value in v) {
  # Check if the value is even using the modulo operator
  if (value %% 2 == 0) {
    # If the value is even, append it to the new vector
    new <- c(new, value)
  }
}

# Print the new vector containing only even values
cat("\nNew Even vector is:")
print(new)
