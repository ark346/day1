# Load the algae dataset, which is assumed to be available in the current environment.
# If using a specific package (like 'DMwR'), ensure it is loaded first with library(DMwR).
data("algae")

# Display the first few rows of the algae dataset to understand its structure and content.
head(algae)

# Task 1: Create a bar plot using ggplot2 to visualize the distribution of water samples across different sizes.
# - ggplot(algae, aes(x = size)): Initialize the plot using the 'algae' dataset.
#   - 'aes(x = size)' maps the 'size' variable to the x-axis.
# - geom_bar(fill = "skyblue"): Adds bars to the plot with a sky-blue fill color. By default, it counts the frequency of each unique value of 'size'.
# - ggtitle(): Sets the main title of the plot.
# - xlab() and ylab(): Define custom labels for the x-axis and y-axis respectively.
ggplot(algae, aes(x = size)) +
  geom_bar(fill = "skyblue") +
  ggtitle("Distribution of Water Samples by Size") +
  xlab("Size of Water Sample") +
  ylab("Count")

# Task 2: Create a similar bar plot using base R's barplot() to compare with ggplot2.
# - table(algae$size): Creates a frequency table for the 'size' column, showing the count of water samples for each unique size value.
# - barplot(): Creates a bar chart based on the frequency table.
#   - 'size_counts' is passed to specify the data.
#   - 'main' sets the title of the bar chart.
#   - 'xlab' and 'ylab' define the labels for the x-axis and y-axis.
#   - 'col = "lightgreen"' sets the fill color for the bars.
size_counts <- table(algae$size)  # Create a frequency table for the size variable
barplot(size_counts, main = "Distribution of Water Samples by Size (Base R)", xlab = "Size", ylab = "Count", col = "lightgreen")

# Task 3: Create histograms to visualize the distribution of algae type 'a1' using both ggplot2 and base R's hist().

# Histogram using ggplot2
# - ggplot(algae, aes(x = a1)): Initialize the plot using the 'algae' dataset.
#   - 'aes(x = a1)' maps the 'a1' variable to the x-axis.
# - geom_histogram(): Creates a histogram.
#   - 'binwidth = 0.5' specifies the width of each bin, which controls the granularity of the histogram.
#   - 'fill = "orange", color = "black"' defines the fill color and border color of the bars.
# - ggtitle(), xlab(), and ylab() are used to set the title and axis labels.
ggplot(algae, aes(x = a1)) +
  geom_histogram(binwidth = 0.5, fill = "orange", color = "black") +
  ggtitle("Distribution of Algae Type a1 (ggplot2)") +
  xlab("Algae Type a1") +
  ylab("Frequency")

# Histogram using base R's hist()
# - hist(algae$a1): Creates a histogram for the 'a1' variable.
#   - 'main' sets the title.
#   - 'xlab' and 'ylab' define labels for the x-axis and y-axis.
#   - 'col = "lightblue"' sets the fill color.
#   - 'border = "black"' sets the border color of the bars.
hist(algae$a1, main = "Distribution of Algae Type a1 (Base R)", xlab = "Algae Type a1", ylab = "Frequency", col = "lightblue", border = "black")
