# Define a recursive function to calculate the number of digits in a number
count_digits <- function(n) {
  # Base case: if n is 0, return 0
  if (n == 0) {
    return(0)
  }
  # Recursive call: divide n by 10 and add 1 to the count
  return(1 + count_digits(n %/% 10))
}

# Define a recursive function to check if a number is an Armstrong number
is_armstrong_recursive <- function(n, original_n = n, power = NULL) {
  # Initialize the power (number of digits) in the first call
  if (is.null(power)) {
    power <- count_digits(n)  # Count the number of digits
  }
  
  # Base case: if n is 0, return 0 (sum of powers)
  if (n == 0) {
    return(0)
  }
  
  # Calculate the last digit and its power
  last_digit <- n %% 10
  sum_of_powers <- last_digit^power  # Raise the last digit to the power of number of digits
  
  # Recursive call: reduce n by removing the last digit
  return(sum_of_powers + is_armstrong_recursive(n %/% 10, original_n, power))
}

# Prompt the user to enter a number to check for Armstrong status
number <- as.numeric(readline(prompt = "Enter a number to check if it is an Armstrong number: "))

# Check if the number is an Armstrong number by comparing the original number with the calculated sum
if (number == is_armstrong_recursive(number)) {
  cat(number, "is an Armstrong number.\n")
} else {
  cat(number, "is not an Armstrong number.\n")
}
