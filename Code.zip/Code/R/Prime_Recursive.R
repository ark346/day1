# Define a recursive function to check if a number is prime
is_prime_recursive <- function(n, divisor = 2) {
  # Base case: if n is less than 2, it is not prime
  if (n < 2) {
    return(FALSE)
  }
  # Base case: if divisor exceeds the square root of n, n is prime
  if (divisor * divisor > n) {
    return(TRUE)
  }
  # If n is divisible by the divisor, it is not prime
  if (n %% divisor == 0) {
    return(FALSE)
  }
  # Recursive call with the next divisor
  return(is_prime_recursive(n, divisor + 1))
}

# Prompt the user to enter a number to check for primality
number <- as.numeric(readline(prompt = "Enter a number to check if it is prime: "))

# Call the recursive function and store the result
if (is_prime_recursive(number)) {
  cat(number, "is a prime number.\n")
} else {
  cat(number, "is not a prime number.\n")
}
