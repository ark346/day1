# Define a recursive function to calculate the factorial of a number
  # The function factorial_recursive takes a single argument n.
  factorial_recursive <- function(n) {
    # Base case: if n is 0 or 1, return 1
    # The factorial of 0 and 1 is defined as 1.
    if (n == 0 || n == 1) {
      return(1)
    } else {
      # Recursive case: n! = n * (n - 1)!
      # The function calls itself with the argument (n - 1) and multiplies the result by n.
      return(n * factorial_recursive(n - 1))
    }
  }

# Prompt the user to enter a number for factorial calculation
# The readline() function reads input from the user. 
# as.numeric() converts the input to a numeric type.
number <- as.numeric(readline(prompt = "Enter a number to calculate its factorial: "))

# Call the recursive function with the user input and store the result
result <- factorial_recursive(number)

# Print the result using cat() to format the output message
# The cat() function prints the factorial of the number along with the number itself.
cat("The factorial of", number, "is", result)
