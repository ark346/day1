# Define a recursive function to find the factors of a number
find_factors_recursive <- function(n, divisor = 1, factors = c()) {
  # Base case: if divisor exceeds n, return the factors
  if (divisor > n) {
    return(factors)
  }
  
  # Check if the current divisor is a factor of n
  if (n %% divisor == 0) {
    # If it's a factor, append it to the factors vector
    factors <- c(factors, divisor)
  }
  
  # Recursive call: increment the divisor
  return(find_factors_recursive(n, divisor + 1, factors))
}

# Prompt the user to enter a number to find its factors
number <- as.numeric(readline(prompt = "Enter a number to find its factors: "))

# Call the recursive function to find factors and store the result
factors <- find_factors_recursive(number)

# Print the factors of the number
cat("The factors of", number, "are:", factors, "\n")
