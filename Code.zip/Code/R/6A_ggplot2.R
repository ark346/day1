# Load the mtcars dataset, which is a built-in dataset in R.
data("mtcars")

# Display the first few rows of the mtcars dataset to understand its structure and content.
head(mtcars)

# Task 1: Create a scatter plot for 'mpg' (Miles per Gallon) vs 'hp' (Horsepower) using ggplot2.
# - ggplot(mtcars, aes(x = hp, y = mpg)): Initialize the plot using the 'mtcars' dataset.
#   - 'aes()' defines the aesthetics for the plot, mapping 'hp' to the x-axis and 'mpg' to the y-axis.
# - geom_point(): Adds points to the scatter plot to represent individual car observations.
# - ggtitle(): Sets the title of the plot.
# - xlab() and ylab(): Define custom labels for the x-axis and y-axis respectively.
ggplot(mtcars, aes(x = hp, y = mpg)) +
  geom_point() +
  ggtitle("Scatter plot of MPG vs Horsepower") +
  xlab("Horsepower") +
  ylab("Miles per Gallon")

# Task 2: Create a bar chart to show the number of cars with different numbers of cylinders.
# - ggplot(mtcars, aes(x = factor(cyl))): Initializes the plot using the 'mtcars' dataset.
#   - 'aes()' maps 'cyl' (number of cylinders) to the x-axis, but converts it into a factor to ensure that each cylinder value is treated as a separate category.
# - geom_bar(): Creates a bar chart, with the height of each bar corresponding to the number of cars for each cylinder count.
# - ggtitle(): Sets the title of the bar chart.
# - xlab() and ylab(): Define custom labels for the x-axis and y-axis.
ggplot(mtcars, aes(x = factor(cyl))) +
  geom_bar() +
  ggtitle("Number of Cars by Cylinder Count") +
  xlab("Number of Cylinders") +
  ylab("Count of Cars")

# Task 3: Create a pie chart to show the proportion of cars with different numbers of gears.
# - table(mtcars$gear): Creates a frequency table for the 'gear' column, showing the count of cars for each gear value.
# - pie(): Generates a pie chart to display the proportions of different gear counts.
#   - 'gear_counts' is passed to specify the data.
#   - 'main = "Proportion of Cars by Gear Count"': Sets the main title of the pie chart.
#   - 'col = rainbow(length(gear_counts))': Defines the color palette using the rainbow() function.
gear_counts <- table(mtcars$gear)  # Create a frequency table for the number of gears in the cars
pie(gear_counts, main = "Proportion of Cars by Gear Count", col = rainbow(length(gear_counts)))
